
from pygameMNG import MNG

__all__ = ['MNG',]
